"use strict";

(function ($) {
  $(document).ready(function () {
    $('body').addClass('stm-lms-user-account');
  });
})(jQuery);