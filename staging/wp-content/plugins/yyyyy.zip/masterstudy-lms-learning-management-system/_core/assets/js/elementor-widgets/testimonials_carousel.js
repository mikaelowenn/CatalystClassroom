"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _get(target, property, receiver) { if (typeof Reflect !== "undefined" && Reflect.get) { _get = Reflect.get; } else { _get = function _get(target, property, receiver) { var base = _superPropBase(target, property); if (!base) return; var desc = Object.getOwnPropertyDescriptor(base, property); if (desc.get) { return desc.get.call(receiver); } return desc.value; }; } return _get(target, property, receiver || target); }

function _superPropBase(object, property) { while (!Object.prototype.hasOwnProperty.call(object, property)) { object = _getPrototypeOf(object); if (object === null) break; } return object; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

var StmLmsProTestimonials = /*#__PURE__*/function (_elementorModules$fro) {
  _inherits(StmLmsProTestimonials, _elementorModules$fro);

  var _super = _createSuper(StmLmsProTestimonials);

  function StmLmsProTestimonials() {
    _classCallCheck(this, StmLmsProTestimonials);

    return _super.apply(this, arguments);
  }

  _createClass(StmLmsProTestimonials, [{
    key: "getDefaultSettings",
    value: function getDefaultSettings() {
      return {
        selectors: {
          carousel: '.swiper-container',
          slideContent: '.swiper-slide'
        }
      };
    }
  }, {
    key: "getDefaultElements",
    value: function getDefaultElements() {
      var selectors = this.getSettings('selectors');
      var elements = {
        $swiperContainer: this.$element.find(selectors.carousel)
      };
      elements.$slides = elements.$swiperContainer.find(selectors.slideContent);
      return elements;
    }
  }, {
    key: "getSwiperSettings",
    value: function getSwiperSettings() {
      return {
        pagination: {
          el: '.ms-lms-elementor-testimonials-swiper-pagination',
          clickable: true,
          renderBullet: function renderBullet(index, className) {
            var userThumbnail = '';
            var testimonialItem = jQuery('.elementor-testimonials-carousel').children().eq(index);

            if (testimonialItem.length > 0) {
              userThumbnail = testimonialItem.attr('data-thumbnail');
            }

            var span = jQuery('<span></span>');
            span.addClass(className);
            span.css("background-image", "url(" + userThumbnail + ")");
            return span.prop('outerHTML');
          }
        }
      };
    }
  }, {
    key: "onInit",
    value: function () {
      var _onInit = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var _get2;

        var _len,
            args,
            _key,
            elementSettings,
            Swiper,
            _args = arguments;

        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                for (_len = _args.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
                  args[_key] = _args[_key];
                }

                (_get2 = _get(_getPrototypeOf(StmLmsProTestimonials.prototype), "onInit", this)).call.apply(_get2, [this].concat(args));

                elementSettings = this.getElementSettings();

                if (!(!this.elements.$swiperContainer.length || 2 > this.elements.$slides.length)) {
                  _context.next = 5;
                  break;
                }

                return _context.abrupt("return");

              case 5:
                Swiper = elementorFrontend.utils.swiper;
                _context.next = 8;
                return new Swiper(this.elements.$swiperContainer, this.getSwiperSettings());

              case 8:
                this.swiper = _context.sent;
                // Expose the swiper instance in the frontend
                this.elements.$swiperContainer.data('swiper', this.swiper);

                if ('yes' === elementSettings.pause_on_hover) {
                  this.togglePauseOnHover(true);
                }

              case 11:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function onInit() {
        return _onInit.apply(this, arguments);
      }

      return onInit;
    }()
  }, {
    key: "updateSwiperOption",
    value: function updateSwiperOption(propertyName) {
      var elementSettings = this.getElementSettings(),
          newSettingValue = elementSettings[propertyName],
          params = this.swiper.params; // Handle special cases where the value to update is not the value that the Swiper library accepts.

      switch (propertyName) {
        case 'space_between':
          params.spaceBetween = newSettingValue.size || 0;
          break;

        case 'autoplay_speed':
          params.autoplay.delay = newSettingValue;
          break;

        case 'speed':
          params.speed = newSettingValue;
          break;
      }

      this.swiper.update();
    }
  }, {
    key: "getChangeableProperties",
    value: function getChangeableProperties() {
      return {
        pause_on_hover: 'pauseOnHover',
        autoplay_speed: 'delay',
        speed: 'speed',
        space_between: 'spaceBetween'
      };
    }
  }, {
    key: "onElementChange",
    value: function onElementChange(propertyName) {
      var changeableProperties = this.getChangeableProperties();

      if (changeableProperties[propertyName]) {
        // 'pause_on_hover' is implemented by the handler with event listeners, not the Swiper library.
        if ('pause_on_hover' === propertyName) {
          var newSettingValue = this.getElementSettings('pause_on_hover');
          this.togglePauseOnHover('yes' === newSettingValue);
        } else {
          this.updateSwiperOption(propertyName);
        }
      }
    }
  }, {
    key: "onEditSettingsChange",
    value: function onEditSettingsChange(propertyName) {
      if ('activeItemIndex' === propertyName) {
        this.swiper.slideToLoop(this.getEditSettings('activeItemIndex') - 1);
      }
    }
  }]);

  return StmLmsProTestimonials;
}(elementorModules.frontend.handlers.SwiperBase);

jQuery(window).on('elementor/frontend/init', function () {
  var addHandler = function addHandler($element) {
    elementorFrontend.elementsHandler.addHandler(StmLmsProTestimonials, {
      $element: $element
    });
  };

  elementorFrontend.hooks.addAction('frontend/element_ready/stm_lms_pro_testimonials.default', addHandler);
});