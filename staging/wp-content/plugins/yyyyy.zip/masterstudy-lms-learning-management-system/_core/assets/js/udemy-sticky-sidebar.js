"use strict";

(function ($) {
  $(document).ready(function () {
    var sidebar = new StickySidebar('.udemy-sidebar-holder', {
      topSpacing: 20
    });
  });
})(jQuery);