<?php

/**
 * @deprecated 2.4.0
 */

if (!defined('ABSPATH')) exit; //Exit if accessed directly

class STM_LMS_WP_Router
{

    public function create_routes()
    {

    }

}