<?php
/**
 * @var $field
 * @var $field_name
 * @var $section_name
 *
 */

$field_key = "data['{$section_name}']['fields']['{$field_name}']";

include STM_LMS_PATH .'/settings/order/components_js/order.php';
?>

<stm-order></stm-order>