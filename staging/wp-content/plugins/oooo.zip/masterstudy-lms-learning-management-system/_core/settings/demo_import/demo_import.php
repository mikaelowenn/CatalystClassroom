<?php stm_lms_register_script('admin/demo_import'); ?>

<demo_import inline-template>
    <?php stm_lms_demo_import_load_template('field'); ?>
</demo_import>