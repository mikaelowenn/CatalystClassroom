<?php

/**
 * @var $lesson_type
 */


switch($lesson_type) {
	case ('video') : ?>
        </div>
        </div>
		</div>
		<?php break;
    case ('slide') : ?>
        </div>
        </div>
        </div>
        <?php break;
	default: ?>
        </div>
        </div>
        </div>
<?php }