<script>
    (function ($) {
        $(document).ready(function () {
            $('body').addClass('stm-lms-template-page');
        });
    })(jQuery);
</script>