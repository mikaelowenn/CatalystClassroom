<?php
/**
 * @var $title
 */

?>

<div class="float_menu_item__divider heading_font">
    <?php echo sanitize_text_field($title); ?>
</div>