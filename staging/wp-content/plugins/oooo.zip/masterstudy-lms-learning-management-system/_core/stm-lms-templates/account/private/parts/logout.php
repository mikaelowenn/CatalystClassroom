<a href="<?php echo wp_logout_url(get_home_url()); ?>" class="stm-lms-logout-button btn btn-default">
    <i class="fas fa-power-off"></i>
    <span>
        <?php esc_html_e('Log out', 'masterstudy-lms-learning-management-system'); ?>
    </span>
</a>