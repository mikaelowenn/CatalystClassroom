<div class="row">

    <div class="col-md-12">
        <div class="form-group form-group-social">

            <label class="heading_font">
                <?php esc_html_e('Bio', 'masterstudy-lms-learning-management-system'); ?>
            </label>

            <textarea v-model="data.meta.description"
                      placeholder="<?php esc_html_e('Enter your BIO', 'masterstudy-lms-learning-management-system'); ?>">
            </textarea>

        </div>
    </div>

</div>