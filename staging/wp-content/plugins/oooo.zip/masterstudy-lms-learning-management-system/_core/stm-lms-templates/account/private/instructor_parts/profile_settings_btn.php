<a href="<?php echo esc_url(STM_LMS_User::settings_url()); ?>" class="stm_lms_instructor_profile_settings">
    <i class="fa fa-cog"></i>
    <?php esc_html_e('Profile settings', 'masterstudy-lms-learning-management-system'); ?>
</a>
