<?php
STM_LMS_User::js_redirect(STM_LMS_User::login_page_url());
die;