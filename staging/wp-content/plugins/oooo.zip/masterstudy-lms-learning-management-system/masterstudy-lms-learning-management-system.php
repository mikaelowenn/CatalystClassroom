<?php
/**
Plugin Name: MasterStudy LMS WordPress Plugin – for Online Courses and Education
Plugin URI: http://masterstudy.stylemixthemes.com/lms-plugin/
Description: Create brilliant lessons with videos, graphs, images, slides and any other attachments thanks to flexible and user-friendly lesson management tool powered by WYSIWYG editor.
As the ultimate LMS WordPress Plugin, MasterStudy makes it simple and hassle-free to build, customize and manage your Online Education WordPress website.
Author: StylemixThemes
Author URI: https://stylemixthemes.com/
Text Domain: masterstudy-lms-learning-management-system
Version: 2.9.33
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'MS_LMS_FILE', __FILE__ );
define( 'MS_LMS_PATH', dirname( MS_LMS_FILE ) );

/* Load Core version */
require_once MS_LMS_PATH . '/_core/init.php';
