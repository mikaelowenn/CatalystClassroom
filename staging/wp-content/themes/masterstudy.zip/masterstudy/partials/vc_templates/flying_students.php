<?php

/**
 * @var $horizontal_align
 */
?>

<div class="row-has-animation <?php echo esc_attr("horizontal_align_{$horizontal_align}"); ?>">

    <?php get_template_part('partials/vc_parts/row_animations/flying_students'); ?>

</div>