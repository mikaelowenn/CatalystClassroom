<?php
/**
 * @var $form_id
 */

if(!empty($form_id)) echo do_shortcode("[contact-form-7 id='{$form_id}']");
