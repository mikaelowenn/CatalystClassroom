<?php
/**
 * @var $css_class
 */
?>

<div class="multiseparator<?php echo esc_attr($css_class); ?>"></div>
