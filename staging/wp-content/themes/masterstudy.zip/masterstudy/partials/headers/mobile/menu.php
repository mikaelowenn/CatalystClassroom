<div class="stm_lms_menu_popup">
    <div class="stm_lms_menu_popup__close">
        <i class="lnr lnr-cross"></i>
    </div>
    <div class="inner">
        <h2><?php esc_html_e('Menu', 'masterstudy'); ?></h2>
        <?php get_template_part('partials/headers/parts/menu'); ?>
    </div>
</div>