"use strict";

(function ($) {
  $(document).ready(function () {
    AOS.init();
  });
})(jQuery);