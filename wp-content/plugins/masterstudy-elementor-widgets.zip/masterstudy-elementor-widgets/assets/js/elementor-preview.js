(function ($) {

    $(window).on( "load" , function () {
        $('html').removeClass('stm-site-preloader');
    });

})(jQuery);