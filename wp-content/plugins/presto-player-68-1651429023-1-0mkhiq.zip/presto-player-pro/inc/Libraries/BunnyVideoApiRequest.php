<?php

namespace PrestoPlayer\Pro\Libraries;

use PrestoPlayer\Pro\Libraries\BunnyApiRequest;

class BunnyVideoApiRequest extends BunnyApiRequest
{
    protected $base_url = 'https://video.bunnycdn.com/';
}
