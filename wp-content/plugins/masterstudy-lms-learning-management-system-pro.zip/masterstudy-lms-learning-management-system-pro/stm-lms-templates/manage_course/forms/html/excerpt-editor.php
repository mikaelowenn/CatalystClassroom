<div>

    <tinymce v-model="excerpt_edited"
             :plugins="myPlugins"
             :toolbar1="myToolbar1"
             :toolbar2="myToolbar2"
             :other="myOtherOptions">
    </tinymce>

</div>